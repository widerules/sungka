package com.sungka.janverski;

import android.app.Activity;
import android.view.View;
import android.view.View.OnClickListener;

public class Tutorial extends Activity implements OnClickListener {

	public void onClick(View v) {
		// TODO Auto-generated method stub

	}

}
